module inertial_integrator(
 input logic clk,rst_n,vld,
 input logic signed [15:0] ptch_rt,AZ,
 output wire signed [15:0] ptch
);
 localparam signed [15:0] PTCH_RT_OFFSET=16'h0050, AZ_OFFSET=16'h00A0;
 logic signed [15:0] ptch_rt_comp,AZ_comp,ptch_acc;
 logic signed [31:0] ptch_acc_product;
 logic signed [26:0] ptch_int,fusion_ptch_offset;
 assign ptch_rt_comp=ptch_rt-PTCH_RT_OFFSET;
 assign AZ_comp=AZ-AZ_OFFSET;
 assign ptch_acc_product=AZ_comp*32'sd327;
 assign ptch_acc={{3{ptch_acc_product[25]}},ptch_acc_product[25:13]};
 assign ptch=ptch_int[26:11];
 assign fusion_ptch_offset=(ptch_acc>ptch) ? 27'sd1024 : -27'sd1024;
 always_ff @(posedge clk or negedge rst_n)
   if(!rst_n) ptch_int<=0;
   else if(vld) ptch_int<=ptch_int-{{11{ptch_rt_comp[15]}},ptch_rt_comp}+fusion_ptch_offset;
endmodule
