module inertial_integrator_tb;
 reg clk=0,rst_n=0,vld=0;
 reg signed [15:0] ptch_rt=0,AZ=0;
 wire signed [15:0] ptch;
 reg signed [26:0] reference_acc=0;
 reg signed [15:0] rate_comp,az_comp,acc_angle,current_angle;
 reg signed [31:0] product;
 integer checks=0;
 always #10 clk=~clk;
 inertial_integrator dut(.*);
 // Independent cycle-by-cycle reference, including fixed-width wrap behavior.
 always @(posedge clk) begin
   if(!rst_n) reference_acc=0;
   else if(vld) begin
     rate_comp=ptch_rt-16'sh0050;
     az_comp=AZ-16'sh00A0;
     product=az_comp*32'sd327;
     acc_angle={{3{product[25]}},product[25:13]};
     current_angle=reference_acc[26:11];
     reference_acc=reference_acc-rate_comp+((acc_angle>current_angle)?1024:-1024);
   end
   #1;
   if(ptch!==reference_acc[26:11]) $fatal(1,"Integrator mismatch");
   checks=checks+1;
 end
 task phase(input reg signed [15:0] rate,input reg signed [15:0] az,input integer cycles);
 begin
   @(negedge clk); ptch_rt=rate; AZ=az; vld=1;
   repeat(cycles) @(negedge clk);
 end
 endtask
 initial begin
   repeat(3) @(negedge clk); rst_n=1;
   phase(16'h1050,0,500);
   if(ptch>=-500) $fatal(1,"Negative gyro integration failed");
   phase(16'h0050,0,1000);
   phase(16'hF050,0,500);
   if(ptch<=0) $fatal(1,"Positive gyro integration failed");
   phase(16'h0050,0,1000);
   phase(16'h0050,16'h0800,3000);
   if(ptch<74 || ptch>76) $fatal(1,"Fusion did not settle at 75: %0d",ptch);
   vld=0; repeat(20) @(negedge clk);
   // Signed inputs and vld gating beyond the prescribed waveform.
   phase(16'h8050,16'h8000,20);
   @(negedge clk); rst_n=0;
   #1; if(ptch!==0) $fatal(1,"Asynchronous reset failed");
   $display("PASS: integrator %0d cycle checks, gyro direction, fusion, vld, reset",checks);
   $finish;
 end
 initial begin #1000000; $fatal(1,"Integrator timeout"); end
endmodule
