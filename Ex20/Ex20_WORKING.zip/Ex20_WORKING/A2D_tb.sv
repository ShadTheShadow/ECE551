module A2D_tb;
 reg clk=0,rst_n=0,nxt=0;
 always #10 clk=~clk;
 wire SS_n,SCLK,MOSI,MISO;
 wire [11:0] lft_ld,rght_ld,steer_pot,batt;
 reg [11:0] expected[0:3];
 integer i,j,ch,transactions=0,rises=0;
 reg [15:0] command_word;
 A2D_Intf dut(.*);
 ADC128S model(.clk(clk),.rst_n(rst_n),.SS_n(SS_n),.SCLK(SCLK),.MOSI(MOSI),.MISO(MISO));
 always @(negedge SS_n) begin rises=0; command_word=0; end
 always @(posedge SCLK) if(!SS_n) begin
   rises=rises+1; command_word={command_word[14:0],MOSI};
 end
 always @(posedge SS_n) if(rst_n) begin
   if(rises!=16) $fatal(1,"Expected 16 SPI rising edges, got %0d",rises);
   if((transactions%2)==0) begin
     case((transactions/2)%4)
       0: ch=0; 1: ch=4; 2: ch=5; 3: ch=6;
     endcase
     if(command_word !== (ch<<11)) $fatal(1,"Wrong command %h",command_word);
   end
   transactions=transactions+1;
 end
 task conversion(input integer index);
   begin
     @(negedge clk); nxt=1;
     @(negedge clk); nxt=0;
     wait(!SS_n); wait(SS_n); wait(!SS_n); wait(SS_n);
     repeat(5) @(negedge clk);
     case(index%4)
       0: ch=0; 1: ch=4; 2: ch=5; 3: ch=6;
     endcase
     expected[index%4]=(12'hC00-index*16)|ch;
     if(lft_ld!==expected[0] || rght_ld!==expected[1] ||
        steer_pot!==expected[2] || batt!==expected[3])
       $fatal(1,"Conversion %0d: got %h %h %h %h",index,lft_ld,rght_ld,steer_pot,batt);
   end
 endtask
 initial begin
   for(j=0;j<4;j=j+1) expected[j]=0;
   repeat(3) @(negedge clk); rst_n=1;
   for(i=0;i<12;i=i+1) conversion(i);
   // Reset after multiple channel wraps and verify the first channel restarts.
   @(negedge clk); rst_n=0;
   #1;
   if({lft_ld,rght_ld,steer_pot,batt}!==48'd0) $fatal(1,"Reset failed");
   transactions=0;
   for(j=0;j<4;j=j+1) expected[j]=0;
   repeat(3) @(negedge clk); rst_n=1;
   conversion(0);
   $display("PASS: A2D 13 conversions, channel commands, holding registers, reset");
   $finish;
 end
 initial begin #1000000; $fatal(1,"A2D timeout"); end
endmodule
