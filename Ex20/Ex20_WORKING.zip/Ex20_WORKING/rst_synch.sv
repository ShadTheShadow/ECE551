module rst_synch (
    input  logic clk,
    input  logic RST_n,
    output logic rst_n
);

    logic rst_meta_n;

    // Assertion is asynchronous.  Deassertion passes through two flops on
    // falling clock edges so the rest of the design sees reset released away
    // from its active (rising) edge.
    always_ff @(negedge clk or negedge RST_n) begin
        if (!RST_n) begin
            rst_meta_n <= 1'b0;
            rst_n      <= 1'b0;
        end else begin
            rst_meta_n <= 1'b1;
            rst_n      <= rst_meta_n;
        end
    end

endmodule
