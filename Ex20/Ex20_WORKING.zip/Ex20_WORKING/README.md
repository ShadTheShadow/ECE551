# Ex20_WORKING — completed and simulation-tested

Use this folder independently; the original Ex20 folder is unchanged.

## Status
- A2D_tb: PASS, 13 conversions covering channels 0/4/5/6, three round-robin passes, command encoding, 16 SPI clocks per transaction, holding registers and reset.
- inertial_integrator_tb: PASS, 6050 cycle comparisons, prescribed five stimulus phases, fusion convergence, signed values, vld gating and reset.
- A2D_test: compiles with Icarus and passes Verilator lint with only unused-bit / case-similar-name warnings.
- Quartus fitting and physical DE0-Nano demonstration have NOT been run.

## Important timing / specification notes
The supplied ADC model takes several system clocks after SS_n rises to update its channel. This implementation leaves four system clocks between command and read transactions to avoid loading the previous channel. Slide 6 illustrates a one-clock gap; this is an intentional deviation to work with the supplied synchronous model and should be checked with teaching staff if the exact illustrated gap is graded.
The final integrator phase converges around 75 counts with AZ=0x0800 using the exact slide equations and offset; the slide's "about 100" is approximate.

## Run in Questa / ModelSim
From this folder:
    vlib work
    vlog -sv SPI_main.sv A2D_Intf.sv SPI_ADC128S.sv ADC128S.sv A2D_tb.sv
    vsim -c A2D_tb -do "run -all; quit -f"
    vlog -sv inertial_integrator.sv inertial_integrator_tb.sv
    vsim -c inertial_integrator_tb -do "run -all; quit -f"

## Submission
The PDF requires one group submission including all members, but does not list exact upload filenames.
Core completed work: A2D_Intf.sv, A2D_tb.sv, SPI_main.sv, inertial_integrator.sv, inertial_integrator_tb.sv.
Board work: A2D_test.sv, PB_release.sv, rst_synch.sv, A2D_test.qpf, A2D_test.qsf.
Simulation dependencies: ADC128S.sv, SPI_ADC128S.sv (unchanged provided models).
Follow any more specific Gradescope upload instructions.

## Interfaces
SPI_main uses the wt_data input name. A2D_Intf and the Quartus project use matching capitalization.
PB_release synchronizes the button and detects release; it does not implement mechanical debounce.
