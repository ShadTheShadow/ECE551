module PB_release (
    input  logic clk,
    input  logic rst_n,
    input  logic PB,
    output logic released
);

    logic pb_meta;
    logic pb_sync;
    logic pb_delayed;

    // The board push button is active low.  Presetting all stages to the
    // unpressed state prevents a false release pulse when reset is removed.
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pb_meta    <= 1'b1;
            pb_sync    <= 1'b1;
            pb_delayed <= 1'b1;
        end else begin
            pb_meta    <= PB;
            pb_sync    <= pb_meta;
            pb_delayed <= pb_sync;
        end
    end

    assign released = pb_sync & ~pb_delayed;

endmodule
