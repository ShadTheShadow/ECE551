module A2D_Intf(
 input logic clk,rst_n,nxt,MISO,
 output logic [11:0] lft_ld,rght_ld,steer_pot,batt,
 output wire SS_n,SCLK,MOSI
);
 typedef enum logic [1:0] {IDLE,COMMAND,GAP,READ} state_t;
 state_t state;
 logic [1:0] robin_cnt;
 logic [1:0] gap_count;
 logic [2:0] channel;
 logic wrt,done;
 logic [15:0] rd_data;
 always_comb
   case(robin_cnt)
     0: channel=0;
     1: channel=4;
     2: channel=5;
     3: channel=6;
   endcase
 assign wrt = ((state==IDLE) && nxt) || ((state==GAP) && (gap_count==2));
 SPI_main iSPI(.clk(clk),.rst_n(rst_n),.wrt(wrt),
   .wt_data({2'b00,channel,11'h000}),.MISO(MISO),
   .SS_n(SS_n),.SCLK(SCLK),.MOSI(MOSI),.done(done),.rd_data(rd_data));
 always_ff @(posedge clk or negedge rst_n)
   if(!rst_n) begin
     state<=IDLE; robin_cnt<=0; gap_count<=0;
     lft_ld<=0; rght_ld<=0; steer_pot<=0; batt<=0;
   end else case(state)
     IDLE: if(nxt) state<=COMMAND;
     COMMAND: if(done) begin state<=GAP; gap_count<=0; end
     // Allow the supplied synchronous ADC model to decode the completed command
     // before its SPI slave loads data for the read transaction.
     GAP: if(gap_count==2) state<=READ;
          else gap_count<=gap_count+2'd1;
     READ: if(done) begin
       case(robin_cnt)
         0: lft_ld<=rd_data[11:0];
         1: rght_ld<=rd_data[11:0];
         2: steer_pot<=rd_data[11:0];
         3: batt<=rd_data[11:0];
       endcase
       robin_cnt<=robin_cnt+2'd1;
       state<=IDLE;
     end
     default: state<=IDLE;
   endcase
endmodule
