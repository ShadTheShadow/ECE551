module SPI_main (
    input  logic        clk, rst_n,
    input  logic        wrt,
    input  logic [15:0] wt_data,
    input  logic        MISO,
    output logic        SS_n,
    output wire         SCLK, MOSI,
    output logic        done,
    output wire [15:0]  rd_data
);
    typedef enum logic [1:0] {IDLE, FRONT, TRANSFER} state_t;
    state_t state, nxt_state;
    logic [3:0] SCLK_div, bit_cntr;
    logic [15:0] shft_reg;
    logic MISO_smpl;
    logic init, ld_SCLK, shft, set_done;
    wire smpl = (SCLK_div == 4'b0111);
    wire shft_imm = (SCLK_div == 4'b1111);
    wire done15 = &bit_cntr;

    assign SCLK = SCLK_div[3];
    assign MOSI = shft_reg[15];
    assign rd_data = shft_reg;

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) state <= IDLE;
        else        state <= nxt_state;

    always_comb begin
        nxt_state = state;
        init = 1'b0;
        ld_SCLK = 1'b0;
        shft = 1'b0;
        set_done = 1'b0;
        case (state)
            IDLE: begin
                ld_SCLK = 1'b1;
                if (wrt) begin
                    init = 1'b1;
                    nxt_state = FRONT;
                end
            end
            // The first falling edge presents bit 15 without shifting it.
            FRONT: if (shft_imm) nxt_state = TRANSFER;
            TRANSFER: if (shft_imm) begin
                shft = 1'b1;
                if (done15) begin
                    // Shift in the last sample, but suppress a 17th fall.
                    ld_SCLK = 1'b1;
                    set_done = 1'b1;
                    nxt_state = IDLE;
                end
            end
            default: begin
                ld_SCLK = 1'b1;
                nxt_state = IDLE;
            end
        endcase
    end

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) SCLK_div <= 4'b1011;
        else if (ld_SCLK) SCLK_div <= 4'b1011;
        else SCLK_div <= SCLK_div + 4'd1;

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) MISO_smpl <= 1'b0;
        else if (smpl) MISO_smpl <= MISO;

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) shft_reg <= 16'h0000;
        else if (init) shft_reg <= wt_data;
        else if (shft) shft_reg <= {shft_reg[14:0], MISO_smpl};

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) bit_cntr <= 4'h0;
        else if (init) bit_cntr <= 4'h0;
        else if (shft) bit_cntr <= bit_cntr + 4'd1;

    // Register both status outputs so SS_n cannot glitch with FSM decode.
    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) SS_n <= 1'b1;
        else if (init) SS_n <= 1'b0;
        else if (set_done) SS_n <= 1'b1;

    always_ff @(posedge clk or negedge rst_n)
        if (!rst_n) done <= 1'b0;
        else if (init) done <= 1'b0;
        else if (set_done) done <= 1'b1;
endmodule
