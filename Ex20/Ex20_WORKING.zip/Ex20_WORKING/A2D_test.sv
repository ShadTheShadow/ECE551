module A2D_test(
 input wire clk,RST_n,SEL,MISO,
 output logic [7:0] LED,
 output wire SCLK,SS_n,MOSI
);
 wire rst_n,released;
 wire [11:0] lft_ld,rght_ld,steer_pot,batt;
 logic [18:0] count;
 logic [1:0] select;
 rst_synch iRST(.clk(clk),.RST_n(RST_n),.rst_n(rst_n));
 PB_release iPB(.clk(clk),.rst_n(rst_n),.PB(SEL),.released(released));
 always_ff @(posedge clk or negedge rst_n)
   if(!rst_n) begin count<=0; select<=0; end
   else begin
     count<=count+19'd1;
     if(released) select<=select+2'd1;
   end
 always_comb
   case(select)
     0: LED=lft_ld[11:4];
     1: LED=rght_ld[11:4];
     2: LED=steer_pot[11:4];
     3: LED=batt[11:4];
   endcase
 A2D_Intf iDUT(.clk(clk),.rst_n(rst_n),.nxt(&count),.MISO(MISO),
   .lft_ld(lft_ld),.rght_ld(rght_ld),.steer_pot(steer_pot),.batt(batt),
   .SS_n(SS_n),.SCLK(SCLK),.MOSI(MOSI));
endmodule
